# Errata for *Using R for Introductory Statistics*, second edition.

