## interface to shiny demos
## Shiny must be installed
demos <- function() {
  source(system.file("shiny", "startup.R", package="UsingR"))
}


